import java.util.Scanner;

public class MainBinarySearch {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Contoh array yang sudah diurutkan
        int[] arr = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
        
        BinarySearch binarySearch = new BinarySearch();

        System.out.print("Masukkan angka yang ingin dicari: ");
        int target = scanner.nextInt();

        int result = binarySearch.search(arr, target);

        if (result != -1)
            System.out.println("Angka di temukan di index: " + result);
        else
            System.out.println("Angka tidak ditemukan dalam array.");

        scanner.close();
    }
}