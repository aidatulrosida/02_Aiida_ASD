import java.util.Scanner;
public class Mahasiswa02Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        Scanner sl = new Scanner(System.in);
        Scanner input = new Scanner(System.in);

        PencarianMhs02 data = new PencarianMhs02();
        System.out.print("Masukkan jumlah mahasiswa: ");
        int jumMhs = input.nextInt();

        System.out.println("------------------------------------------------------");
        System.out.println("Masukkan data mahasiswa secara Urut dari Nim Terkecil");
        for (int i = 0; i < jumMhs; i++) {
            System.out.println("--------------------------------------------------");
            System.out.print("Nim\t: ");
            int nim = s.nextInt();
            s.nextLine(); // Membersihkan newline di buffer
            System.out.print("Nama\t: ");
            String nama = s.nextLine(); // Menggunakan nextLine() untuk mengambil input string
            System.out.print("Umur\t: ");
            int umur = s.nextInt();
            System.out.print("IPK\t: ");
            double ipk = s.nextDouble();

            Mahasiswa02 m = new Mahasiswa02(nim, nama, umur, ipk);
            data.tambah(m);
        }

        System.out.println("-------------------------------------------------------");
        System.out.println("Data keseluruhan Mahasiswa : ");
        data.tampil();

        System.out.println("_______________________________________________________");
        System.out.println("_______________________________________________________");
        System.out.println("Pencarian Data : ");
        System.out.println("Masukkan Nama Mahasiswa yang dicari: ");
        System.out.print("Nama Mahasiswa: ");
        String cari = sl.nextLine();
        System.out.println("Menggunakan sequential Search");
        int posisi = data.FindSeqSearch(cari);
        data.Tampilposisi(cari, posisi);
        data.TampilData(cari, posisi);

        System.out.println("==========================================================");
        System.out.println("Menggunakan binary Search");
        posisi = data.FindBinarySearch(cari, 0, jumMhs - 1);
        data.Tampilposisi(cari, posisi);
        data.TampilData(cari, posisi);
        data.detectMultipleResults(cari, posisi);
    }
}