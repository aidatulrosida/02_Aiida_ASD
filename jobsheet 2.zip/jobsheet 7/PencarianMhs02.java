public class PencarianMhs02 {
    Mahasiswa02 listMhs[] = new Mahasiswa02[5];
    int idx;

    void tambah(Mahasiswa02 m) {
        if (idx < listMhs.length) {
            listMhs[idx] = m;
            idx++;
        } else {
            System.out.println("Data sudah penuh !!!");
        }
    }

    void tampil() {
        for (Mahasiswa02 m : listMhs) {
            if (m != null) {
                m.tampil();
                System.out.println("==========================================");
            }
        }
    }

    public int FindSeqSearch(String cari) {
        int posisi = -1;
        for (int j = 0; j < listMhs.length; j++) {
            if (listMhs[j] != null && listMhs[j].nama.equalsIgnoreCase(cari)) {
                posisi = j;
                break;
            }
        }
        return posisi;
    }

    public void Tampilposisi(String x, int pos) {
        if (pos != -1) {
            System.out.println("Data " + x + " ditemukan pada indeks " + pos);
        } else {
            System.out.println("Data " + x + " tidak ditemukan");
        }
    }

    public void TampilData(String x, int pos) {
        if (pos != -1) {
            System.out.println("Nama\t : " + x);
            System.out.println("Nim\t : " + listMhs[pos].nim);
            System.out.println("Umur\t : " + listMhs[pos].umur);
            System.out.println("IPK\t : " + listMhs[pos].ipk);
        } else {
            System.out.println("Data " + x + " tidak ditemukan");
        }
    }

    public int FindBinarySearch(String cari, int left, int right) {
        int mid;
        if (right >= left) {
            mid = (left + right) / 2;
            int compareResult = listMhs[mid].nama.compareToIgnoreCase(cari);
            if (compareResult == 0) {
                return mid; // Data ditemukan
            } else if (compareResult > 0) {
                return FindBinarySearch(cari, left, mid - 1); // Cari di bagian kiri
            } else {
                return FindBinarySearch(cari, mid + 1, right); // Cari di bagian kanan
            }
        }
        return -1; // Data tidak ditemukan
    }

    public void detectMultipleResults(String cari, int firstResultIndex) {
        int count = 1;
        int index = firstResultIndex - 1;
        while (index >= 0 && listMhs[index] != null && listMhs[index].nama.equalsIgnoreCase(cari)) {
            count++;
            index--;
        }
        index = firstResultIndex + 1;
        while (index < listMhs.length && listMhs[index] != null && listMhs[index].nama.equalsIgnoreCase(cari)) {
            count++;
            index++;
        }

        if (count > 1) {
            System.out.println("Peringatan: Terdapat " + count + " hasil pencarian dengan nama " + cari);
        }
    }
}
