public class NodeTugas2 {
    String question;
    String answer;
    NodeTugas2 nextNode;

    NodeTugas2(String question, String answer) {
        this.question = question;
        this.answer = answer;
        this.nextNode = null;
    }
}