public class DragonMain02 {
    public static void main(String[] args) {
        Dragon02 drg02 = new Dragon02();
        drg02.x = 3;
        drg02.y = 2;
        drg02.width = 5;
        drg02.height = 5;
        drg02.moveDown();
        drg02.moveRight();
        drg02.moveLeft();
        drg02.moveUp();
        drg02.moveUp();
        drg02.moveUp();
    }
}