import java.util.Scanner;
public class MainPangkat {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("========================================================");
        System.out.print("Masukkan jumlah elemen yang ingin dihitung: ");
        int elemen = sc.nextInt();

        Pangkat[] png = new Pangkat[elemen];

        for (int i = 0; i < elemen; i++) {
            png[i] = new Pangkat();
            System.out.print("Masukkan nilai yang akan dipangkatkan ke-" + (i + 1) + " : ");
            png[i].nilai = sc.nextInt();
            System.out.print("Masukkan nilai pemangkat ke-" + (i + 1) + " : ");
            png[i].pangkat = sc.nextInt();
        }

        System.out.println("=============================");
        System.out.println("Pilih Metode yang Ingin Dijalankan: ");
        System.out.println("1. Brute Force");
        System.out.println("2. Divide and Conquer");
        System.out.println("Masukkan pilihan anda: ");
        int Pilih = sc.nextInt();

        while (true) {
            switch (Pilih) {
                case 1:
                   System.out.println("=============================");
                   System.out.println("Hasil Pangkat denan Brute Force");
                   for ( int i = 0; i < elemen; i++){
                    System.out.println("Nilai "+png[i].nilai + " Pangkat " + png[i].pangkat + "adalah: "+ png[i].pangkatDC(png[i].nilai, png[i].pangkat));
                   }
                    break;
                case 2:
                System.out.println("=============================="); 
                System.out.println("Hasil Pangkat dengan Divide and Conquer");
                for (int i = 0; i < elemen; i++){
                    System.out.println("Nilai " + png[i].nilai + " Pangkat " + png[i].pangkat + "adalah: "+ png[i].pangkatDC(png[i].nilai, png[i].pangkat));
                } 
                break;

                default:
                System.out.println("==============================");
                System.out.println("==============================");
                System.out.println("Pilih Metode yang ingin dijalankan");
                System.out.println("1. Brute Force");
                System.out.println("2. Divide and Conque");
                System.out.println("Masukkan Pilihan Anda");
                Pilih = sc.nextInt();
            }
            if (Pilih == 1 || Pilih == 2){
                break;
            }
        }   
    }
        
}