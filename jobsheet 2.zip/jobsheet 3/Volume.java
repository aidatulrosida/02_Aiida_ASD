public class Volume {
    private double panjang;
    private double lebar;
    private double tinggi;

    // Constructor
    public Volume(double panjang, double lebar, double tinggi) {
        this.panjang = panjang;
        this.lebar = lebar;
        this.tinggi = tinggi;
    }

    // Getter methods
    public double getPanjang() {
        return panjang;
    }

    public double getLebar() {
        return lebar;
    }

    public double getTinggi() {
        return tinggi;
    }

    // Setter methods
    public void setPanjang(double panjang) {
        this.panjang = panjang;
    }

    public void setLebar(double lebar) {
        this.lebar = lebar;
    }

    public void setTinggi(double tinggi) {
        this.tinggi = tinggi;
    }

    // Method untuk menghitung volume
    public double hitungVolume() {
        return panjang * lebar * tinggi;
    }
}