import java.util.Scanner;

public class  LaporanPendapatanDemo{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=======================================");
        System.out.println("         LAPORAN PENDAPATAN");
        System.out.println("=======================================");

        System.out.print("Masukkan tanggal (format: DD-MM-YYYY): ");
        String tanggalInput = scanner.next();
        
        // Mempisahkan tanggal, bulan, dan tahun
        String[] tanggalArray = tanggalInput.split("-");
        int tanggal = Integer.parseInt(tanggalArray[0]);
        int bulan = Integer.parseInt(tanggalArray[1]);
        int tahun = Integer.parseInt(tanggalArray[2]);

        System.out.print("Masukkan total pendapatan: ");
        double totalPendapatan = scanner.nextDouble();
        
        LaporanPendapatan laporanPendapatan = new LaporanPendapatan(tanggal, bulan, tahun, totalPendapatan);
        
        System.out.println("=======================================");
        System.out.println("Tanggal: " + laporanPendapatan.getTanggal() + "-" + laporanPendapatan.getBulan() + "-" + laporanPendapatan.getTahun());
        System.out.println("Total Pendapatan: " + laporanPendapatan.getTotalPendapatan());
        System.out.println("=======================================");
    }
}
