public class Node02 {
    int data;
    Node02 left;
    Node02 right;

    public Node02() {
    }
    public Node02(int data) {
        this.left = null;
        this.data = data;
        this.right = null;
    }
}