public class BinaryTree02 {
    Node02 root;

    public BinaryTree02() {
        root = null;
    }

    boolean isEmpty() {
        return root == null;
    }

    // Metode untuk menambahkan node secara rekursif
    Node02 addRecursive(Node02 current, int data) {
        if (current == null) {
            return new Node02(data);
        }

        if (data < current.data) {
            current.left = addRecursive(current.left, data);
        } else if (data > current.data) {
            current.right = addRecursive(current.right, data);
        }

        return current;
    }

    public void add(int data) {
        root = addRecursive(root, data);
    }

    // Metode untuk menampilkan nilai paling kecil dalam tree
    public int findMinValue() {
        if (isEmpty()) {
            throw new IllegalStateException("Tree is empty");
        }
    
        Node02 current = root;
        while (current.left != null) {
            current = current.left;
        }
    
        return current.data;
    }
    
    // Metode untuk menampilkan nilai paling besar dalam tree
    public int findMaxValue() {
        if (isEmpty()) {
            throw new IllegalStateException("Tree is empty");
        }
    
        Node02 current = root;
        while (current.right != null) {
            current = current.right;
        }
    
        return current.data;
    }    

    // Method untuk menampilkan data yang ada di leaf
    public void printLeafNodes(Node02 node) {
        if (node == null) {
            return;
        } else if (node.left == null && node.right == null) {
            System.out.print(node.data + " ");
        }
        printLeafNodes(node.left);
        printLeafNodes(node.right);
    }

    // Method untuk memulai pencetakan data leaf
    public void printLeafNodes() {
        System.out.print("Leaf Nodes          : ");
        printLeafNodes(root);
        System.out.println();
    }

    // Metode untuk menghitung jumlah leaf nodes
    public int countLeafNodes() {
        return countLeafNodes(root);
    }

    // Metode rekursif untuk menghitung jumlah leaf nodes
    public int countLeafNodes(Node02 node) {
        if (node == null) {
            return 0;
        } else if (node.left == null && node.right == null) {
            return 1;
        }
        int leftCount = countLeafNodes(node.left);
        int rightCount = countLeafNodes(node.right);
        return leftCount + rightCount;
    }

    boolean find(int data) {
        Node02 current = root;
        while (current != null) {
            if (current.data == data) {
                return true;
            } else if (data < current.data) {
                current = current.left;
            } else {
                current = current.right;
            }
        }
        return false;
    }

    void traversePreOrder(Node02 node) {
        if (node != null) {
            System.out.print(" " + node.data);
            traversePreOrder(node.left);
            traversePreOrder(node.right);
        }
    }

    void traverseInOrder(Node02 node) {
        if (node != null) {
            traverseInOrder(node.left);
            System.out.print(" " + node.data);
            traverseInOrder(node.right);
        }
    }

    void traversePostOrder(Node02 node) {
        if (node != null) {
            traversePostOrder(node.left);
            traversePostOrder(node.right);
            System.out.print(" " + node.data);
        }
    }

    Node02 getSuccessor(Node02 del) {
        Node02 successor = del.right;
        Node02 successorParent = del;
        while (successor.left != null) {
            successorParent = successor;
            successor = successor.left;
        }
        if (successor != del.right) {
            successorParent.left = successor.right;
            successor.right = del.right;
        }
        return successor;
    }

    void delete(int data) {
        if (isEmpty()) {
            System.out.println("Tree is empty!");
            return;
        }
        // find node (currrent) that willl be deleted
        Node02 parent = root;
        Node02 current = root;
        boolean isLeftChild = false;

        while (current != null) {
            if (current.data == data) {
                break;
            } else if (data < current.data) {
                parent = current;
                current = current.left;
                isLeftChild = true;
            } else {
                parent = current;
                current = current.right;
                isLeftChild = false;
            }
        }

        if (current == null) {
            System.out.println("Couldn't find data!");
            return;
        } else {
        //if there is no child, simply delete it
        if (current.left == null && current.right == null) {
            if (current == root) {
                root = null;
            } else {
                if (isLeftChild) {
                    parent.left = null;
                } else {
                    parent.right = null;
                }
            }
        } else if (current.left == null) { //if there is 1 child (right)
            if (current == root) {
                root = current.right;
            } else {
                if (isLeftChild) {
                    parent.left = current.right;
                } else {
                    parent.right = current.right;
                }
            }
        } else if (current.right == null) { //if there is 1 child (left)
            if (current == root) {
                root = current.left;
            } else {
                if (isLeftChild) {
                    parent.left = current.left;
                } else {
                    parent.right = current.left;
                }
            }
        } else { //if there is 1 child (right)
            Node02 successor = getSuccessor(current);
            if (current == root) {
                root = successor;
            } else {
                if (isLeftChild) {
                    parent.left = successor;
                } else {
                    parent.right = successor;
                }
            }
            successor.left = current.left;
        }
    }
}
}