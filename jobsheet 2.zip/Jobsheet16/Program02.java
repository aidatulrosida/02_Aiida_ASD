import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.LinkedList;

public class Program02 {
    public List<Mahasiswa002> daftarMahasiswa = new ArrayList<>();
    public List<MataKuliah02> daftarMataKuliah = new ArrayList<>();
    public List<Nilai02> daftarNilai = new ArrayList<>();
    public Queue<Mahasiswa002> antrianMahasiswa = new LinkedList<>();

    public void inputNilai(String NIM, String kodeMK, double nilai) {
        Mahasiswa002 mahasiswa = cariMahasiswa(NIM);
        MataKuliah02 mataKuliah = cariMataKuliah(kodeMK);

        if (mahasiswa != null && mataKuliah != null) {
            Nilai02 nilaiMahasiswa = new Nilai02(mahasiswa, mataKuliah, nilai);
            daftarNilai.add(nilaiMahasiswa);
            System.out.println("Nilai berhasil ditambahkan untuk Mahasiswa dengan NIM " + NIM +
                    " pada Mata Kuliah dengan Kode " + kodeMK);
        } else {
            System.out.println("Gagal menambahkan nilai karena NIM " + NIM + " atau Mata Kuliah dengan kode " + kodeMK +
                    " tidak ditemukan.");
        }
    }

    public void tambahMahasiswa(Mahasiswa002 mahasiswa) {
        daftarMahasiswa.add(mahasiswa);
        antrianMahasiswa.offer(mahasiswa); 
    }    

    public void tambahMataKuliah(MataKuliah02 mataKuliah) {
        daftarMataKuliah.add(mataKuliah);
    }

    public void hapusMahasiswa() {
        if (!antrianMahasiswa.isEmpty()) {
            Mahasiswa002 mahasiswa = antrianMahasiswa.poll(); 
            daftarMahasiswa.remove(mahasiswa); 
            System.out.println("Mahasiswa " + mahasiswa.getNama() + " dihapus dari antrian dan daftar mahasiswa.");
            return; 
        }
        System.out.println("Antrian mahasiswa kosong. Tidak ada mahasiswa yang bisa dihapus.");
    }     

    public void tampilDaftarMahasiswa() {
        if (daftarMahasiswa.isEmpty()) {
            System.out.println("Daftar mahasiswa kosong.");
        } else {
            System.out.println("\n\n\033[1;92m---------------\n\033[0mDaftar Mahasiswa\n\033[1;92m---------------\033[0m");
            for (Mahasiswa002 mahasiswa : daftarMahasiswa) {
                System.out.printf("\033[1;97m%-15s %-25s %-15s\033[0m\n", mahasiswa.getNIM(), mahasiswa.getNama(), mahasiswa.getNomorTelepon());
                System.out.println("\033[1;92m------------------------------------------------\033[0m");
            }
        }
    }

    public void tampilNilai() {
        if (daftarNilai.isEmpty()) {
            System.out.println("\nBelum ada data nilai yang dimasukkan.");
        } else {
            System.out.println("                      \nDAFTAR NILAI MAHASISWA                              ");
            System.out.println("============================================================================");
            System.out.println("|   NIM   |       Nama       |         Mata Kuliah           | SKS | Nilai |");
            System.out.println("============================================================================");
            for (Nilai02 nilai : daftarNilai) {                    
                System.out.printf("| %-8s| %-17s| %-30s| %-4d| %-6.2f|\n", 
                    nilai.getMahasiswa().getNIM(), nilai.getMahasiswa().getNama(),
                    nilai.getMataKuliah().getNamaMK(), nilai.getMataKuliah().getSKS(), nilai.getNilai());
                }
                System.out.println("============================================================================");
        }
    }

    public Mahasiswa002 cariMahasiswa(String NIM) {
        for (Mahasiswa002 mahasiswa : daftarMahasiswa) {
            if (mahasiswa.getNIM().equals(NIM)) {
                return mahasiswa;
            }
        }
        return null;
    }    

    public MataKuliah02 cariMataKuliah(String kodeMK) {
        for (MataKuliah02 mataKuliah : daftarMataKuliah) {
            if (mataKuliah.getKodeMK().equals(kodeMK)) {
                return mataKuliah;
            }
        }
        return null;
    }

    public void tampilNilaiMahasiswa(String NIM) {
        Mahasiswa002 mahasiswa = cariMahasiswa(NIM);
        if (mahasiswa != null) {
            List<Nilai02> nilaiMahasiswa = new ArrayList<>();
            for (Nilai02 nilai : daftarNilai) {
                if (nilai.getMahasiswa().getNIM().equals(NIM)) {
                    nilaiMahasiswa.add(nilai);
                }
            }
            if (!nilaiMahasiswa.isEmpty()) {
                System.out.println("\nDAFTAR NILAI MAHASISWA");
                System.out.println("============================================================================");
                System.out.println("|   NIM   |       Nama       |         Mata Kuliah           | SKS | Nilai |");
                System.out.println("============================================================================");
                for (Nilai02 nilai : nilaiMahasiswa) {
                    System.out.printf("| %-8s| %-17s| %-30s| %-4d| %-6.2f|\n",
                            nilai.getMahasiswa().getNIM(), nilai.getMahasiswa().getNama(),
                            nilai.getMataKuliah().getNamaMK(), nilai.getMataKuliah().getSKS(), nilai.getNilai());
                }
                System.out.println("============================================================================");
            } else {
                System.out.println("\nBelum ada data nilai untuk mahasiswa dengan NIM " + NIM);
            }
        } else {
            System.out.println("\nMahasiswa dengan NIM " + NIM + " tidak ditemukan.");
        }
    }    

    public void urutDataNilai() {
        if (daftarNilai.isEmpty()) {
            System.out.println("\nBelum ada data nilai yang dimasukkan.");
        } else {
            Collections.sort(daftarNilai, new Comparator<Nilai02>() {
                @Override
                public int compare(Nilai02 nilai1, Nilai02 nilai2) {
                    return Double.compare(nilai1.getNilai(), nilai2.getNilai());
                }
            });

            System.out.println("                      \nDAFTAR NILAI MAHASISWA                              ");
            System.out.println("============================================================================");
            System.out.println("|   NIM   |       Nama       |         Mata Kuliah           | SKS | Nilai |");
            System.out.println("============================================================================");
            for (Nilai02 nilai : daftarNilai) {
                System.out.printf("| %-8s| %-17s| %-30s| %-4d| %-6.2f|\n", 
                                    nilai.getMahasiswa().getNIM(), nilai.getMahasiswa().getNama(),
                                    nilai.getMataKuliah().getNamaMK(), nilai.getMataKuliah().getSKS(), nilai.getNilai());
            }
            System.out.println("============================================================================");
        }
    }
}