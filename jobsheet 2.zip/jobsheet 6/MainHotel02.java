import java.util.Scanner;
public class MainHotel02 {
    public static void main(String[] args) {
        HotelService02 list = new HotelService02();
        Hotel02 h1 = new Hotel02("HotelMawar", "Malang", 170000, (byte) 4);
        Hotel02 h2 = new Hotel02("HotelMelati", "Surabaya", 190000, (byte) 5);
        Hotel02 h3 = new Hotel02("HotelAnggrek", "Semarang", 130000, (byte) 2);
        Hotel02 h4 = new Hotel02("HotelTulip", "Sidoarjo", 150000, (byte) 3);
        Hotel02 h5 = new Hotel02("HotelLily", "Kediri", 110000, (byte) 1);

        list.tambah(h1);
        list.tambah(h2);
        list.tambah(h3);
        list.tambah(h4);
        list.tambah(h5);

        System.out.println("Data hotel sebelum sorting = ");
        list.tampilALL();

        System.out.println("Data hotel setelah sorting asc berdasarkan harga");
        list.bubbleSortAsc();
        list.tampilALL();

        System.out.println("Data hotel setelah sorting desc berdasarkan harga");
        list.selectionSortDesc();
        list.tampilALL();

        System.out.println("Data hotel setelah sorting desc berdasarkan bintang");
        list.bubbleSortDesc();
        list.tampilALL();

        System.out.println("Data hotel setelah sorting asc berdasarkan bintang");
        list.selectionSortAsc();
        list.tampilALL();
    }
}