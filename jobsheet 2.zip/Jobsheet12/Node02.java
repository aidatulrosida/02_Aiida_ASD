public class Node02 {
    int data;
    Node02 prev, next;
    
    Node02(Node02 prev, int data, Node02 next) {
        this.prev = prev;
        this.data = data;
        this.next = next;
    }
}