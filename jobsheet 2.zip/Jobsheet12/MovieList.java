class MovieList {
    NodeFilm head;
    NodeFilm tail;

    public void tambahDataAwal(Film film) {
        NodeFilm newNode = new NodeFilm(film);
        if (head == null) {
            head = tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
    }

    public void tambahDataAkhir(Film film) {
        NodeFilm newNode = new NodeFilm(film);
        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }

    public void tambahDataIndexTertentu(int urutan, Film film) {
        NodeFilm newNode = new NodeFilm(film);
    
        if (head == null) {
            head = tail = newNode;
            return;
        }
    
        if (urutan <= 1) {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
            return;
        }
    
        NodeFilm current = head;
        int counter = 1;
        while (current != null && counter < urutan - 1) {
            current = current.next;
            counter++;
        }
    
        if (current == null) {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        } else {
            newNode.next = current.next;
            if (current.next != null) {
                current.next.prev = newNode;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }
    
    public void hapusDataPertama() {
        if (head == null) {
            System.out.println("Data film kosong");
        } else if (head == tail) {
            head = tail = null;
        } else {
            head = head.next;
            head.prev = null;
        }
    }

    public void hapusDataTerakhir() {
        if (head == null) {
            System.out.println("Data film kosong");
        } else if (head == tail) {
            head = tail = null;
        } else {
            tail = tail.prev;
            tail.next = null;
        }
    }

    public void hapusDataTertentu(int filmId) {
        NodeFilm current = head;
        while (current != null) {
            if (current.film.id == filmId) {
                if (current == head) {
                    hapusDataPertama();
                } else if (current == tail) {
                    hapusDataTerakhir();
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                }
                return;
            }
            current = current.next;
        }
        System.out.println("Film dengan ID " + filmId + " tidak ditemukan");
    }

    public void cetak() {
        NodeFilm current = head;
        int counter = 1;
        while (current != null) {
            System.out.println("ID: " + current.film.id);
            System.out.println("Judul Film: " + current.film.judul);
            System.out.println("Rating: " + current.film.rating);
            System.out.println();
            current = current.next;
            counter++;
        }
    }

    public void cariIDFilm(int idCari) {
        NodeFilm current = head;
        int nodeCounter = 1;
        boolean found = false;
    
        while (current != null) {
            if (current.film.id == idCari) {
                found = true;
                break;
            }
            current = current.next;
            nodeCounter++;
        }
    
        if (found) {
            System.out.println("Data ID Film: " + idCari + " berada di node ke-" + nodeCounter);
            System.out.println("IDENTITAS:");
            System.out.println("ID Film    : " + current.film.id);
            System.out.println("Judul Film : " + current.film.judul);
            System.out.println("IMDB Rating: " + current.film.rating);
        } else {
            System.out.println("Film dengan ID " + idCari + " tidak ditemukan");
        }
    }
    
    public void urutDataRatingFilm_DESC() {
        if (head == null) {
            return;
        }

        NodeFilm sorted = null;
        NodeFilm current = head;

        while (current != null) {
            NodeFilm next = current.next;
            if (sorted == null || sorted.film.rating <= current.film.rating) {
                current.next = sorted;
                if (sorted != null) {
                    sorted.prev = current;
                }
                sorted = current;
                sorted.prev = null;
            } else {
                NodeFilm temp = sorted;
                while (temp.next != null && temp.next.film.rating > current.film.rating) {
                    temp = temp.next;
                }
                current.next = temp.next;
                if (temp.next != null) {
                    temp.next.prev = current;
                }
                temp.next = current;
                current.prev = temp;
            }
            current = next;
        }

        head = sorted;
        NodeFilm tempTail = head;
        while (tempTail.next != null) {
            tempTail = tempTail.next;
        }
        tail = tempTail;
    }

    public void keluar() {
        System.out.println("Terima kasih!");
    }
}