public class DoubleLinkedList_2 {
    Node head, tail;
    int size;

    public DoubleLinkedList_2() {
        head = tail = null;
        size = 0;
    }

    public void tambahFilm(int id, String judul, double rating) {
        Film film = new Film(id, judul, rating);
        Node newNode = new Node(film);

        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        size++;
    }

    public Film hapusFilmPertama() {
        if (head == null) {
            return null;
        }
        Film data = head.data;
        head = head.next;
        if (head != null) {
            head.prev = null;
        } else {
            tail = null;
        }
        size--;
        return data;
    }

    public Film hapusFilmTerakhir() {
        if (tail == null) {
            return null;
        }
        Film data = tail.data;
        tail = tail.prev;
        if (tail != null) {
            tail.next = null;
        } else {
            head = null;
        }
        size--;
        return data;
    }

    public void cariFilmByID(int id) {
        Node current = head;
        boolean found = false;

        while (current != null) {
            if (current.data.getId() == id) {
                System.out.println("Film ditemukan:");
                System.out.println("ID: " + current.data.getId());
                System.out.println("Judul: " + current.data.getJudul());
                System.out.println("Rating: " + current.data.getRating());
                found = true;
                break;
            }
            current = current.next;
        }

        if (!found) {
            System.out.println("Film dengan ID " + id + " tidak ditemukan.");
        }
    }

    public void urutRatingDescending() {
        if (head == null) {
            return;
        }

        Node current = head, index;
        Film temp;

        while (current != null) {
            index = current.next;

            while (index != null) {
                if (current.data.getRating() < index.data.getRating()) {
                    temp = current.data;
                    current.data = index.data;
                    index.data = temp;
                }
                index = index.next;
            }
            current = current.next;
        }
    }

    public void cetakDaftarFilm() {
        Node current = head;

        if (head == null) {
            System.out.println("Daftar film masih kosong.");
        } else {
            System.out.println("Daftar Film:");
            while (current != null) {
                System.out.println("ID: " + current.data.getId() + ", Judul: " + current.data.getJudul() + ", Rating: " + current.data.getRating());
                current = current.next;
            }
        }
    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty() {
        return head == null;
    }
}