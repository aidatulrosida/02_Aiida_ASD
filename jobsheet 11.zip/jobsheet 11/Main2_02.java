public class Main2_02 {
    public static void main(String[] args) {
        ScavengerHunt02 scavengerHunt = new ScavengerHunt02();
        scavengerHunt.addPoint("Siapakah penemu teleskop?", "Galileo Galilei");
        scavengerHunt.addPoint("Kapan teleskop pertama kali digunakan untuk mengamati langit?", "1609");
        scavengerHunt.addPoint("Apa nama planet terbesar di tata surya kita?", "Jupiter");

        System.out.println("-------------------------------------------------------------------");
        System.out.println("                         SELAMAT DATANG                            ");
        System.out.println("----------------------~GAME SCAVENGER HUNT~------------------------");
        System.out.println("    Anda harus menjawab pertanyaan untuk menemukan berlian !   ");
        if (scavengerHunt.playGame()) {
            System.out.println("-------------------------------------------------------------------");
            System.out.println("Selamat! Anda berhasil menjawab semua pertanyaan dengan benar!");
            System.out.println("                Anda mendapatkan berlian!                      ");
            System.out.println("-------------------------------------------------------------------");
        } else {
            System.out.println("---------------------------------------------------------------");
            System.out.println("Sayangnya, Anda gagal menjawab semua pertanyaan dengan benar.");
            System.out.println("Silakan coba lagi lain waktu.");
            System.out.println("---------------------------------------------------------------");
        }
    }
}