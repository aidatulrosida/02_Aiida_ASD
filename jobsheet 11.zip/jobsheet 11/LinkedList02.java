public class LinkedList02 {
    Node02 head;

    public boolean isEmpty() {
        return (head == null);
    }

    public void print() {
        if (!isEmpty()) {
            System.out.print("Isi linked list: ");
            Node02 currentNode = head;

            while (currentNode != null) {
                System.out.print(currentNode.data + "\t");
                currentNode = currentNode.next;
            }

            System.out.println("");
        } else {
            System.out.println("Linked list kosong");
        }
    }

    public void addFirst(int input) {
        Node02 newNode = new Node02(input, null);

        if (isEmpty()) {
            head = newNode;
        } else {
            newNode.next = head;
            head = newNode;
        }
    }

    public void addLast(int input) {
        Node02 newNode = new Node02(input, null);

        if (isEmpty()) {
            head = newNode;
        } else {
            Node02 currentNode = head;

            while (currentNode.next != null) {
                currentNode = currentNode.next;
            }

            currentNode.next = newNode;
        }
    }

    public void insertAt(int index, int key) {
        Node02 newNode = new Node02(key, null);

        if (index == 0) {
            newNode.next = head;
            head = newNode;
            return;
        }

        Node02 temp = head;
        int count = 0;
        while (temp != null) {
            if (count == index - 1) {
                break;
            }
            temp = temp.next;
            count++;
        }

        if (count == index - 1) {
            newNode.next = temp.next;
            temp.next = newNode;
        } else {
            System.out.println("Index tidak valid");
        }
    }

    public void removeFirst() {
        if (!isEmpty()) {
            head = head.next;
        } else {
            System.out.println("Linked list kosong");
        }
    }

    public void removeLast() {
        if (!isEmpty()) {
            if (head.next == null) {
                head = null;
            } else {
                Node02 currentNode = head;

                while (currentNode.next.next != null) {
                    currentNode = currentNode.next;
                }

                currentNode.next = null;
            }
        } else {
            System.out.println("Linked list kosong");
        }
    }

    public void remove(int key) {
        if (!isEmpty()) {
            if (head.data == key) {
                removeFirst();
            } else {
                Node02 currentNode = head;

                while (currentNode.next != null) {
                    if (currentNode.next.data == key) {
                        currentNode.next = currentNode.next.next;
                        break;
                    }
                    currentNode = currentNode.next;
                }
            }
        } else {
            System.out.println("Linked list kosong");
        }
    }

    public int getData(int index) {
        Node02 currentNode = head;
        int currentIndex = 0;
    
        while (currentNode != null && currentIndex < index) {
            currentNode = currentNode.next;
            currentIndex++;
        }
    
        if (currentNode == null) {
            System.out.println("Index melebihi jumlah node pada linked list");
            return -1; 
        } else {
            return currentNode.data;
        }
    }
    

    public int indexOf(int key) {
        Node02 currentNode = head;
        int index = 0;

        while (currentNode != null && currentNode.data != key) {
            currentNode = currentNode.next;
            index++;
        }
        if (currentNode == null) {
            return -1;
        } else {
            return index;
        }
    }
}