public class Node02 {
    int data;
    Node02 next;

    public Node02(int data, Node02 next) {
        this.data =data;
        this.next = next;
    }
}

