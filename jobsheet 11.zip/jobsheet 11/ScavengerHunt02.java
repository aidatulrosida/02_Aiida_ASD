import java.util.Scanner;
public class ScavengerHunt02 {
    NodeTugas2 head;

    ScavengerHunt02() {
        this.head = null;
    }

    void addPoint(String question, String answer) {
        NodeTugas2 newNodeTugas2 = new NodeTugas2(question, answer);
        if (head == null) {
            head = newNodeTugas2;
        } else {
            NodeTugas2 current = head;
            while (current.nextNode != null) {
                current = current.nextNode;
            }
            current.nextNode = newNodeTugas2;
        }
    }

    boolean playGame() {
        Scanner scanner = new Scanner(System.in);
        NodeTugas2 current = head;
        while (current != null) {
            System.out.println(current.question);
            System.out.print("Jawaban Anda: ");
            String userAnswer = scanner.nextLine();
            if (userAnswer.equalsIgnoreCase(current.answer)) {
                System.out.println("Jawaban Anda benar! Anda dapat melanjutkan ke point berikutnya.");
                current = current.nextNode;
            } else {
                System.out.println("Jawaban Anda salah! Coba lagi.");
                scanner.close();
                return false;
            }
        }
        scanner.close();
        return true;
    }
}
