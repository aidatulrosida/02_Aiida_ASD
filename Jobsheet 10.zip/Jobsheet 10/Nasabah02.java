public class Nasabah02 {
    String norek;
    String nama;
    String alamat;
    int umur;
    double saldo;

    Nasabah02(String norek, String nama, String alamat, int umur, double saldo) {
        this.norek = norek;
        this.nama = nama;
        this.alamat = alamat;
        this.umur = umur;
        this.saldo = saldo;
    }   
}