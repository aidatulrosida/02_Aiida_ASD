public class Pasien02 {
    public String nama;
    public int noID;
    public char jenisKelamin;
    public int umur;

    public Pasien02(String nama, int noID, char jenisKelamin, int umur) {
        this.nama = nama;
        this.noID = noID;
        this.jenisKelamin = jenisKelamin;
        this.umur = umur;
    }
}