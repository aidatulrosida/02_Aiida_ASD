import java.util.Scanner;

public class ProgramMain02 {
    public static void main(String[] args) {
        Program02 program = new Program02();
        Scanner scanner = new Scanner(System.in);

        // Data mahasiswa
        program.tambahMahasiswa(new Mahasiswa002("20001", "Thalhah", "021xxx"));
        program.tambahMahasiswa(new Mahasiswa002("20002", "Zubair", "021xxx"));
        program.tambahMahasiswa(new Mahasiswa002("20003", "Abdur-Rahman", "021xxx"));
        program.tambahMahasiswa(new Mahasiswa002("20004", "Sa'ad", "021xxx"));
        program.tambahMahasiswa(new Mahasiswa002("20005", "Sa'id", "021xxx"));
        program.tambahMahasiswa(new Mahasiswa002("20006", "Ubaidah", "021xxx"));

        // Data matakuliah
        program.tambahMataKuliah(new MataKuliah02("00001", "Internet of Things", 3));
        program.tambahMataKuliah(new MataKuliah02("00002", "Algoritma dan Struktur Data", 2));
        program.tambahMataKuliah(new MataKuliah02("00003", "Algoritma dan Pemrograman", 2));
        program.tambahMataKuliah(new MataKuliah02("00004", "Praktikum Algoritma dan Struktur Data", 3));
        program.tambahMataKuliah(new MataKuliah02("00005", "Praktikum Algoritma dan Pemrograman", 3));

        int choice;
        do {
            System.out.println("=================================================");
            System.out.println(" SISTEM PENGOLAHAN DATA NILAI MAHASISWA SEMESTER ");
            System.out.println("=================================================");
            System.out.println("----------------------Menu-----------------------");
            System.out.println("=================================================");
            System.out.println("|     Pilihan    |          Deskripsi           |");
            System.out.println("=================================================");
            System.out.println("| 1              | Input Nilai                  |");
            System.out.println("| 2              | Tampil Nilai                 |");
            System.out.println("| 3              | Mencari Nilai Mahasiswa      |");
            System.out.println("| 4              | Urut Data Nilai              |");
            System.out.println("| 5              | Hapus Mahasiswa              |");
            System.out.println("| 6              | Keluar                       |");
            System.out.println("=================================================");
            System.out.print("Pilih menu: ");

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    tampilkanDaftarMahasiswa(program);
                    inputNilai(scanner, program);
                    break;
                case 2:
                    program.tampilNilai();
                    break;
                case 3:
                    program.tampilNilai();
                    System.out.print("Masukkan NIM Mahasiswa yang ingin dicari: ");
                    String nim = scanner.nextLine();
                    program.tampilNilaiMahasiswa(nim);
                    break;                                        
                case 4:
                    program.urutDataNilai();
                    break;          
                case 5:
                    program.hapusMahasiswa();
                    break;                                
                case 6:
                    System.out.println("~ Terima Kasih ~");
                    break;
                default:
                    System.out.println("\nPilihan tidak valid.");
            }
        } while (choice != 6);

        scanner.close();
    }

    public static void inputNilai(Scanner scanner, Program02 program) {
        System.out.println("                  DAFTAR MATA KULIAH                  ");
        System.out.println("======================================================");
        System.out.println("| Kode  |          Nama Mata Kuliah            | SKS |");
        System.out.println("======================================================");
        for (MataKuliah02 mataKuliah : program.daftarMataKuliah) {
            System.out.printf("| %-5s| %-38s| %-3d |\n", mataKuliah.getKodeMK(), mataKuliah.getNamaMK(), mataKuliah.getSKS());
        }
        System.out.println("======================================================");
    
        System.out.println("\nInput Nilai Mahasiswa");
        System.out.print("Masukkan NIM              : ");
        String nim = scanner.nextLine();
        Mahasiswa002 mahasiswa = program.cariMahasiswa(nim);
    
        if (mahasiswa != null) {
            System.out.print("Masukkan Kode Mata Kuliah : ");
            String kodeMK = scanner.nextLine();
    
            System.out.print("Masukkan Nilai            : ");
            double nilai = scanner.nextDouble();
            scanner.nextLine(); 
    
            program.inputNilai(mahasiswa.getNIM(), kodeMK, nilai);
        } else {
            System.out.println("\nMahasiswa dengan NIM " + nim + " tidak ditemukan.");
        }
    }
    
    
    public static void tampilkanDaftarMahasiswa(Program02 program) {
        System.out.println("               DAFTAR MAHASISWA                 ");
        System.out.println("==================================================");
        System.out.println("|     NIM    |       Nama       |  Nomor Telepon |");
        System.out.println("==================================================");
    
        for (int i = 0; i < program.daftarMahasiswa.size(); i++) {
            Mahasiswa002 mahasiswa = program.daftarMahasiswa.get(i);
            System.out.printf("| %-11s| %-17s| %-15s|\n", mahasiswa.getNIM(), mahasiswa.getNama(), mahasiswa.getNomorTelepon());
        }
    
        System.out.println("==================================================");
    }
    

    public static void cariMahasiswa(String nim, Program02 program) {
        Mahasiswa002 mahasiswa = program.cariMahasiswa(nim);
        if (mahasiswa != null) {
            System.out.println("\nData Mahasiswa ditemukan:");
            System.out.printf("NIM: %s\nNama: %s\nNomor Telepon: %s\n", mahasiswa.getNIM(), mahasiswa.getNama(), mahasiswa.getNomorTelepon());
            System.out.println("\nDaftar Nilai Mahasiswa:");
            for (Nilai02 nilai : program.daftarNilai) {
                if (nilai.getMahasiswa().getNIM().equals(nim)) {
                    MataKuliah02 mataKuliah = nilai.getMataKuliah();
                    System.out.printf("Mata Kuliah: %s, Nilai: %.2f\n", mataKuliah.toString(), nilai.getNilai());
                }
            }
        } else {
            System.out.println("\nMahasiswa dengan NIM " + nim + " tidak ditemukan.");
        }
    }
}