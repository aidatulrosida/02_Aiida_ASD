public class MataKuliah02 {
    public String kodeMK;
    public String namaMK;
    public int SKS;

    public MataKuliah02(String kodeMK, String namaMK, int SKS) {
        this.kodeMK = kodeMK;
        this.namaMK = namaMK;
        this.SKS = SKS;
    }

    public String getKodeMK() {
        return kodeMK;
    }

    public String getNamaMK() {
        return namaMK;
    }

    public int getSKS() {
        return SKS;
    }

    @Override
    public String toString() {
        return "Kode: " + kodeMK + ", Nama: " + namaMK + ", SKS: " + SKS;
    }
}