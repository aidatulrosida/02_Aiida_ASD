public class Nilai02 {
    public Mahasiswa002 mahasiswa;
    public MataKuliah02 mataKuliah;
    public double nilai;

    public Nilai02(Mahasiswa002 mahasiswa, MataKuliah02 mataKuliah, double nilai) {
        this.mahasiswa = mahasiswa;
        this.mataKuliah = mataKuliah;
        this.nilai = nilai;
    }

    public Mahasiswa002 getMahasiswa() {
        return mahasiswa;
    }

    public MataKuliah02 getMataKuliah() {
        return mataKuliah;
    }

    public double getNilai() {
        return nilai;
    }
}