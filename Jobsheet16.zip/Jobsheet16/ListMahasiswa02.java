import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class ListMahasiswa02 {
    List<Mahasiswa02> mahasiswas = new ArrayList<>();

    public void tambah(Mahasiswa02... mahasiswa) {
        mahasiswas.addAll(Arrays.asList(mahasiswa));
    }

    public void hapus(int index) {
        mahasiswas.remove(index);
    }

    public void update(int index, Mahasiswa02 mhs) {
        mahasiswas.set(index, mhs);
    }

    public void tampil() {
        mahasiswas.forEach(mhs -> {
            System.out.println(mhs.toString());
        });
    }

    public void sortAscending() {
        Collections.sort(mahasiswas, Comparator.comparing(m -> m.nim));
    }

    public void sortDescending() {
        Collections.sort(mahasiswas, (m1, m2) -> m2.nim.compareTo(m1.nim));
    }

    int binarySearch(String nim) {
        Collections.sort(mahasiswas, (m1, m2) -> m1.nim.compareTo(m2.nim));
        int index = Collections.binarySearch(mahasiswas, new Mahasiswa02(nim, "", ""), Comparator.comparing(m -> m.nim));
        return index >= 0 ? index : -1;
    }

    public static void main(String[] args) {
        ListMahasiswa02 lm = new ListMahasiswa02();
        Mahasiswa02 m = new Mahasiswa02("201234", "Noureen", "021xx1");
        Mahasiswa02 m2 = new Mahasiswa02("201235", "Akhleema", "021xx2");
        Mahasiswa02 m3 = new Mahasiswa02("201236", "Shannum", "021xx3");

        lm.tambah(m, m2, m3);
        lm.tampil();
        lm.update(lm.binarySearch("201235"), new Mahasiswa02("202135", "Akhleema Lela", "021xx2"));
        System.out.println("");
        lm.tampil();

        lm.sortAscending();
        System.out.println("\nSetelah diurutkan secara ascending:");
        lm.tampil();

        lm.sortDescending();
        System.out.println("\nSetelah diurutkan secara descending:");
        lm.tampil();
    }
}