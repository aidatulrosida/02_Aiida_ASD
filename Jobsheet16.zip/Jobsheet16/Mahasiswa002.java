public class Mahasiswa002 {
    public String NIM;
    public String nama;
    public String nomorTelepon;

    public Mahasiswa002(String NIM, String nama, String nomorTelepon) {
        this.NIM = NIM;
        this.nama = nama;
        this.nomorTelepon = nomorTelepon;
    }

    public String getNIM() {
        return NIM;
    }

    public String getNama() {
        return nama;
    }

    public String getNomorTelepon() {
        return nomorTelepon;
    }
}