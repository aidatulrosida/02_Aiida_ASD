class DoubleLinkedList {
    public Node head;
    public Node tail;
    public int size;

    public class Node {
        public PenerimaVaksin data;
        public Node next;
        public Node prev;

        public Node(PenerimaVaksin data) {
            this.data = data;
        }
    }

    public void enqueue(int noAntrian, String nama) {
        PenerimaVaksin newPenerima = new PenerimaVaksin(nama, noAntrian);
        Node newNode = new Node(newPenerima);
        if (tail != null) {
            tail.next = newNode;
            newNode.prev = tail;
        }
        tail = newNode;
        if (head == null) {
            head = tail;
        }
        size++;
    }

    public PenerimaVaksin dequeue() {
        if (head == null) {
            return null;
        }
        PenerimaVaksin data = head.data;
        head = head.next;
        if (head != null) {
            head.prev = null;
        } else {
            tail = null;
        }
        size--;
        return data;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public int size() {
        return size;
    }

    public void printQueue() {
        Node current = head;
        System.out.println("+++++++++++++++++++++++");
        System.out.println("Daftar Pengantri Vaksin");
        System.out.println("+++++++++++++++++++++++");
        if (current == null) {
            System.out.println("Antrian kosong.");
        } else {
            System.out.println("| Nomor Antrian | Nama Penerima |");
            System.out.println("+++++++++++++++++++++++++++++++++");
            while (current != null) {
                System.out.printf("| %-13d | %-13s |\n", current.data.getNoAntrian(), current.data.getNama());
                current = current.next;
            }
        }
    }
}