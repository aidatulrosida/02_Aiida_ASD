class NodeFilm {
    Film film;
    NodeFilm prev;
    NodeFilm next;

    NodeFilm(Film film) {
        this.film = film;
        prev = null;
        next = null;
    }
}