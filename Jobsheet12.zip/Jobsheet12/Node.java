public class Node {
    Film data;
    Node prev, next;

    public Node(Film data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}