class PenerimaVaksin {
    public String nama;
    public int noAntrian;

    public PenerimaVaksin(String nama, int noAntrian) {
        this.nama = nama;
        this.noAntrian = noAntrian;
    }

    public String getNama() {
        return nama;
    }

    public int getNoAntrian() {
        return noAntrian;
    }
}