import java.util.Scanner;

public class BinarySearch {
    public int search(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            // Cek apakah target berada di tengah
            if (arr[mid] == target)
                return mid;
            // Jika target lebih besar, abaikan setengah kiri
            else if (arr[mid] < target)
                left = mid + 1;
            // Jika target lebih kecil, abaikan setengah kanan
            else
                right = mid - 1;
        }

        // Jika target tidak ditemukan
        return -1;
    }
}