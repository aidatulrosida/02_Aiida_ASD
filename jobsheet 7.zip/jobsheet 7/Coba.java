public class Coba {
    public static void main(String[] args) {
        int i = 0;
        for ( i = 0; i < 5; i++) {
            break;
        }
        System.out.print(i);
        }
    }