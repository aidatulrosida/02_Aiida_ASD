import java.util.Scanner;;
public class SortingMain02 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Sorting02 sort = new Sorting02();

        int[] daftarNilai = { 10, 5, 20, 15, 80, 45 };
        sort.sequentialSearch(daftarNilai, 5);

        
        int[] sortedNilai  = { 5, 5, 10, 20, 30, 40, 50 };
        int index = sort.binarySearchAsc(sortedNilai, 5);

        if (index != -1){
            System.out.println("Data ditemukan pada indeks ke-" + index);
        } else {
            System.out.println("Data tidak ditemukan");
        }
}
}