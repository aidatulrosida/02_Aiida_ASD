public class HotelService02 {
    Hotel02 listHtl[] = new Hotel02[5];
    int idx;

    void tambah(Hotel02 h) {
        if(idx < listHtl.length) {
            listHtl[idx] = h;
            idx++;
        } else {
            System.out.println("Kamar sudah penuh!!!");
        }
    }

    void tampilALL() {
        for(Hotel02 h : listHtl) {
            h.tampil();
            System.out.println("----------------------------------");
        }
    }

    void bubbleSortAsc() {
        int n = listHtl.length;
        for (int i = 0; i < n -1; i++) {
            for (int j = 0; j < n - i -1; j++) {
                if (listHtl[j].harga > listHtl[j + 1].harga) {
                    //Swap
                    Hotel02 temp = listHtl[j];
                    listHtl[j] = listHtl [j+1];
                    listHtl[j +1] = temp;
                }
            }
        }
    }
    
    void bubbleSortDesc() {
        int n = listHtl.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (listHtl[j].harga < listHtl[j + 1].harga) {
                    // Swap
                    Hotel02 temp = listHtl[j];
                    listHtl[j] = listHtl[j + 1];
                    listHtl[j + 1] = temp;
                }
            }
        }
    }
    
    void selectionSortDesc() {
        int n = listHtl.length;
        for (int i = 0; i < n -1; i++) {
            int maxIdx = i;
            for (int j = i + 1; j < n; j++) {
                if (listHtl[j].bintang > listHtl[maxIdx].bintang) {
                    maxIdx = j;
                }
            }
            //swap
            Hotel02 temp = listHtl[maxIdx];
            listHtl[maxIdx] = listHtl[i];
            listHtl[i] = temp;
        }
    }
    
    void selectionSortAsc() {
        int n = listHtl.length;
        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < n; j++) {
                if (listHtl[j].bintang < listHtl[minIdx].bintang) {
                    minIdx = j;
                }
            }
            // Swap
            Hotel02 temp = listHtl[minIdx];
            listHtl[minIdx] = listHtl[i];
            listHtl[i] = temp;
        }
    }
    
}