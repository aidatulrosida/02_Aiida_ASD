public class LaporanPendapatan {

    private int tanggal;
    private int bulan;
    private int tahun;
    private double totalPendapatan;

    public LaporanPendapatan(int tanggal, int bulan, int tahun, double totalPendapatan) {
        this.tanggal = tanggal;
        this.bulan = bulan;
        this.tahun = tahun;
        this.totalPendapatan = totalPendapatan;
    }

    public int getTanggal() {
        return tanggal;
    }

    public void setTanggal(int tanggal) {
        this.tanggal = tanggal;
    }

    public int getBulan() {
        return bulan;
    }

    public void setBulan(int bulan) {
        this.bulan = bulan;
    }

    public int getTahun() {
        return tahun;
    }

    public void setTahun(int tahun) {
        this.tahun = tahun;
    }

    public double getTotalPendapatan() {
        return totalPendapatan;
    }

    public void setTotalPendapatan(double totalPendapatan) {
        this.totalPendapatan = totalPendapatan;
    }
}
