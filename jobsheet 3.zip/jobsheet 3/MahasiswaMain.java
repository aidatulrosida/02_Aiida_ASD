import java.io.PrintStream;
import java.util.Scanner;

public class MahasiswaMain {
   public MahasiswaMain() {
   }

   public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
      Mahasiswa[] mahasiswa = new Mahasiswa[3];

      int i;
      for(i = 0; i < mahasiswa.length; ++i) {
         System.out.println("=======================================");
         System.out.println(      "Masukkan Data Mahasiswa ke-" + (i + 1));
         System.out.println("=======================================");
         System.out.print(  "Masukkan Nama          : ");
         String nama =sc.nextLine();
         System.out.print(  "Masukkan NIM           : ");
         long nim = sc.nextLong();
         sc.nextLine();
         System.out.print(  "Masukkan Jenis Kelamin : ");
         String jenisKelamin = sc.nextLine();
         System.out.print(  "Masukkan IPK           : ");
         double ipk = sc.nextDouble();
         sc.nextLine();
         mahasiswa[i] = new Mahasiswa(nama, nim, jenisKelamin, ipk);

      }

      System.out.println();

      for(i = 0; i < mahasiswa.length; ++i) {
         System.out.println("=============================================");
         System.out.println(  "Data Mahasiswa ke-" + (i + 1));
         System.out.println("=============================================");
         System.out.println(  "Nama            : " + mahasiswa[i].nama);
         System.out.println(  "NIM             : " + mahasiswa[i].nim);
         System.out.println(  "Jenis Kelamin   : " + mahasiswa[i].jenisKelamin);
         System.out.println(  "IPK             : " + mahasiswa[i].ipk);
         System.out.println("=============================================");
         System.out.println();
         
      }

      double rataIpk = Mahasiswa.rataIPK(mahasiswa);
      PrintStream var10000 = System.out;
      double var10001 = (double)Math.round(rataIpk * 100.0);
      System.out.println("=============================================");
      var10000.println("         Rata-rata IPK  : " + var10001 / 100.0);
      System.out.println("=============================================");
      Mahasiswa maxIpkMahasiswa = Mahasiswa.IPKterbesar(mahasiswa);
      Mahasiswa.tampilkanIPKterbesar(maxIpkMahasiswa);
   }
}