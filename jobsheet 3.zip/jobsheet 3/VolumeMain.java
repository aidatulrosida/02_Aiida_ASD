import java.util.Scanner;
public class VolumeMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-------------------------");
        System.out.print("Jumlah barang     : ");
        int jumlahBarang = scanner.nextInt();

        // Array untuk menampung objek
        Volume[] barangArray = new Volume[jumlahBarang];

        // Membaca input dan membuat objek untuk setiap barang
        for (int i = 0; i < jumlahBarang; i++) {
            System.out.println("-------------------------");
            System.out.println("Barang ke-" + (i + 1));
            System.out.print("Panjang barang    : ");
            double panjang = scanner.nextDouble();
            System.out.print("Lebar barang      : ");
            double lebar = scanner.nextDouble();
            System.out.print("Tinggi barang     : ");
            double tinggi = scanner.nextDouble();
            System.out.println("=========================");

            // Membuat objek dan menyimpannya di array
            barangArray[i] = new Volume(panjang, lebar, tinggi);
        }
        System.out.println("=========================");
        

        // Menampilkan informasi dan volume untuk setiap barang
        for (int i = 0; i < jumlahBarang; i++) {
            System.out.println("Barang ke-" + (i + 1));
            System.out.println("Panjang          : " + barangArray[i].getPanjang());
            System.out.println("Lebar            : " + barangArray[i].getLebar());
            System.out.println("Tinggi           : " + barangArray[i].getTinggi());
            System.out.println("Volume           : " + barangArray[i].hitungVolume());
            System.out.println();

            System.out.println("=========================");
        }
    }
}