import java.util.ArrayList;
import java.util.Scanner;

public class Tugas1_02 {
    public static void main(String[] args) {
        // Inisialisasi ArrayList untuk menyimpan data mahasiswa
        ArrayList<Mahasiswa> mahasiswaList = new ArrayList<>();

        // Inisialisasi Scanner untuk input dari user
        Scanner scanner = new Scanner(System.in);

        // Jumlah mahasiswa yang akan diinput
        System.out.print("Masukkan jumlah mahasiswa: ");
        int jumlahMahasiswa = scanner.nextInt();

        // Looping untuk menginput data mahasiswa
        for (int i = 1; i <= jumlahMahasiswa; i++) {
            System.out.println("Masukkan informasi untuk Mahasiswa ke-" + i);

            // Input Nama
            System.out.print("Masukkan Nama: ");
            String nama = scanner.next();

            // Input NIM
            System.out.print("Masukkan NIM: ");
            String nim = scanner.next();

            // Input Jenis Kelamin
            System.out.print("Masukkan Jenis Kelamin: ");
            char jenisKelamin = scanner.next().charAt(0);

            // Input IPK
            System.out.print("Masukkan IPK: ");
            double ipk = scanner.nextDouble();

            // Membuat object mahasiswa
            Mahasiswa mahasiswa = new Mahasiswa(nama, nim, jenisKelamin, ipk);

            // Menambahkan object mahasiswa ke dalam ArrayList
            mahasiswaList.add(mahasiswa);
        }

        // Menampilkan informasi mahasiswa menggunakan foreach
        System.out.println("\nInformasi Mahasiswa:");
        for (Mahasiswa mahasiswa : mahasiswaList) {
            System.out.println("Nama: " + mahasiswa.getNama());
            System.out.println("NIM: " + mahasiswa.getNim());
            System.out.println("Jenis Kelamin: " + mahasiswa.getJenisKelamin());
            System.out.println("IPK: " + mahasiswa.getIpk());
            System.out.println();
        }

        // Menghitung rata-rata IPK
        double totalIpk = 0;
        for (Mahasiswa mahasiswa : mahasiswaList) {
            totalIpk += mahasiswa.getIpk();
        }
        double rataRataIpk = totalIpk / jumlahMahasiswa;

        // Menampilkan informasi rata-rata IPK
        System.out.println("Rata-rata IPK: " + rataRataIpk);
    }
}

// Class Mahasiswa untuk menyimpan informasi mahasiswa
class Mahasiswa {
    private String nama;
    private String nim;
    private char jenisKelamin;
    private double ipk;

    public Mahasiswa(String nama, String nim, char jenisKelamin, double ipk) {
        this.nama = nama;
        this.nim = nim;
        this.jenisKelamin = jenisKelamin;
        this.ipk = ipk;
    }

    public String getNama() {
        return nama;
    }

    public String getNim() {
        return nim;
    }

    public char getJenisKelamin() {
        return jenisKelamin;
    }

    public double getIpk() {
        return ipk;
    }
}
