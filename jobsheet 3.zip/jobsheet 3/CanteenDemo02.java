public class CanteenDemo02 {
    public static void main(String[] args) {
       Item02 item1 = new Item02("Nasi goreng", 15000, 10);
       Item02 item2 = new Item02("Donat gula", 3000, 20);
       Item02 item3 = new Item02("Cimory", 7000, 15);

       Item02[] items = new Item02[3];
       items[0] = item1;
       items[1] = item2;
       items[2] = item3;

       for (int i = 0; i < items.length; i++) {
           items[i].displayInfo();
           System.out.println();
      }
   }
}