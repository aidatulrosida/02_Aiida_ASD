public class Pakaian02 {
    String jenis, warna, merk, ukuran;
    double harga;

    Pakaian02(String jenis, String warna, String merk, String ukuran, double harga) {
        this.jenis = jenis;
        this.warna = warna;
        this.merk = merk;
        this.ukuran = ukuran;
        this.harga = harga;
    }
}