import java.util.Scanner;

public class StackMain02 {
    public static void main(String[] args) {
        Stack stk = new Stack(5);
        Scanner sc = new Scanner(System.in);
        char pilihan;

        do {
            System.out.println("==============================");
            System.out.println(" MENU UTAMA ");
            System.out.println("==============================");
            System.out.println(" 1. PUSH");
            System.out.println(" 2. POP");
            System.out.println(" 3. PEEK");
            System.out.println(" 4. PRINT");
            System.out.println(" 5. Max Price");
            System.out.println(" 6. Keluar dari program");
            System.out.print(" Masukkan pilihan anda (1-6): ");
            pilihan = sc.next().charAt(0);
            switch (pilihan) {
                case '1':
                    do {
                        if (stk.IsFull()) {
                            System.out.println("Stack sudah penuh!");
                            break;
                        }

                        System.out.println("\nIsi data pakaian:");
                        System.out.print("Jenis: ");
                        String jenis = sc.next();
                        System.out.print("Warna: ");
                        String warna = sc.next();
                        System.out.print("Merk: ");
                        String merk = sc.next();
                        System.out.print("Ukuran: ");
                        String ukuran = sc.next();
                        System.out.print("Harga: ");
                        double harga = sc.nextDouble();
                        Pakaian02 pakaian = new Pakaian02(jenis, warna, merk, ukuran, harga);
                        System.out.print("Apakah anda akan menambahkan data baru ke stack (y/n)? ");
                        pilihan = sc.next().charAt(0);
                        stk.push(pakaian);
                    } while (pilihan == 'y');
                    break;
                case '2':
                    if (stk.IsEmpty()) {
                        System.out.println("Stack kosong!");
                    } else {
                        stk.pop();
                    }
                    break;
                case '3':
                    if (stk.IsEmpty()) {
                        System.out.println("Stack kosong!");
                    } else {
                        System.out.println("Data di puncak stack:");
                        stk.peek();
                    }
                    break;
                case '4':
                    stk.print();
                    break;
                case '5':
                    // Bagian untuk mencari dan menampilkan data dengan harga tertinggi
                    stk.getMax();
                    break;
                case '6':
                    System.out.println("Keluar dari program");
                    break;
                default:
                    System.out.println("Masukkan pilihan yang BENAR!");
                    break;
            }
        } while (pilihan != '0');
    }
}
