public class StackDemo02 {
    public static void main(String[] args) {
        Stack02 stack02 = new Stack02(10);
        stack02.push(8);
        stack02.push(12);
        stack02.push(18);
        stack02.print();
        stack02.pop();
        stack02.peek();
        stack02.pop();
        stack02.push(-5);
        stack02.print();
    }
}